/****
 * Author: Xiao Li (xiaol4)
 * Project 4 - WizardWorldGateway
 * Description: Servlet for rendering the operations dashboard with analytics and logs.
 * Reference: ChatGPT
 */
package com.xiaoli.wizardworld.gateway;

import com.xiaoli.wizardworld.gateway.dao.LogDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;

import java.io.IOException;
import java.util.List;

/** Dashboard servlet that retrieves logs, computes analytics, and forwards data to dashboard.jsp */
public class DashboardServlet extends HttpServlet {

    private LogDAO dao = new LogDAO();

    /**
     * Handle GET requests for the dashboard.
     * Fetches logs and analytics from MongoDB, attaches them to the request,
     * and forwards to dashboard.jsp for rendering.
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Fetch logs from MongoDB
        List<Document> logs = dao.findAll();
        List<Document> topSpells = dao.getTopSearchedSpells(10);
        double avgLatency = dao.getAverageLatency();

        // Pass data to JSP
        req.setAttribute("logs", logs);
        req.setAttribute("topSpells", topSpells);
        req.setAttribute("avgLatency", avgLatency);

        // Forward to JSP page
        req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
    }
}
