/**
 * Author: Xiao Li (xiaol4)
 * Project 4 - WizardWorldGateway
 * Description: Data model representing a single log entry stored in MongoDB.
 * Reference: ChatGPT
 */
package com.xiaoli.wizardworld.gateway.log;

public class LogEntry {
    private String timestamp;
    private String clientInput;
    private String type;
    private String incantation;
    private long latencyMs;
    private String apiUrl;
    private int apiStatus;
    private boolean found;

    /** Get the timestamp for this log entry. */
    public String getTimestamp() {
        return timestamp;
    }
    /** Set the timestamp for this log entry. */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    /** Get the client input string. */
    public String getClientInput() {
        return clientInput;
    }
    /** Set the client input string. */
    public void setClientInput(String clientInput) {
        this.clientInput = clientInput;
    }

    /** Get the spell type filter used in the request. */
    public String getType() {
        return type;
    }
    /** Set the spell type filter used in the request. */
    public void setType(String type) {
        this.type = type;
    }

    /** Get the incantation filter used in the request. */
    public String getIncantation() {
        return incantation;
    }
    /** Set the incantation filter used in the request. */
    public void setIncantation(String incantation) {
        this.incantation = incantation;
    }

    /** Get the measured latency of the API call in milliseconds. */
    public long getLatencyMs() {
        return latencyMs;
    }
    /** Set the measured latency of the API call in milliseconds. */
    public void setLatencyMs(long latencyMs) {
        this.latencyMs = latencyMs;
    }

    /** Get the API URL that was requested. */
    public String getApiUrl() {
        return apiUrl;
    }
    /** Set the API URL that was requested. */
    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    /** Get the status code returned by the third-party API. */
    public int getApiStatus() {
        return apiStatus;
    }
    /** Set the status code returned by the third-party API. */
    public void setApiStatus(int apiStatus) {
        this.apiStatus = apiStatus;
    }

    /** Whether a matching spell result was found. */
    public boolean isFound() {
        return found;
    }
    /** Set whether a matching spell result was found. */
    public void setFound(boolean found) {
        this.found = found;
    }
}