
/**
 * Author: Xiao Li (xiaol4)
 * Project 4 - WizardWorldGateway
 * Description: Client utility class for calling the Wizard World third‑party API
 * Reference: ChatGPT
 */
package com.xiaoli.wizardworld.gateway.client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class WizardWorldAPIClient {

    private static final String BASE_URL = "https://wizard-world-api.herokuapp.com/Spells";

    private static String lastUrl = "";
    private static int lastStatus = -1;

    /** Return the last requested full URL (for logging/debug). */
    public static String getLastUrl() {
        return lastUrl;
    }

    /** Return the last HTTP status code received. */
    public static int getLastStatus() {
        return lastStatus;
    }

    /**
     * Fetch spells from the Wizard World API using optional filters.
     * @param name Spell name filter
     * @param type Spell type filter
     * @param incantation Spell incantation filter
     * @return JSON string returned by the API
     * @throws Exception if network or IO error occurs
     */
    public static String fetchSpells(String name, String type, String incantation) throws Exception {

        StringBuilder fullUrl = new StringBuilder(BASE_URL + "?");

        if (name != null && !name.isEmpty()) {
            fullUrl.append("Name=").append(URLEncoder.encode(name, "UTF-8")).append("&");
        }
        if (type != null && !type.isEmpty()) {
            fullUrl.append("Type=").append(URLEncoder.encode(type, "UTF-8")).append("&");
        }
        if (incantation != null && !incantation.isEmpty()) {
            fullUrl.append("Incantation=").append(URLEncoder.encode(incantation, "UTF-8")).append("&");
        }

        return httpGet(fullUrl.toString());
    }

    /**
     * Execute a simple HTTP GET request.
     * Records lastUrl and lastStatus for logging.
     * @param urlString Full request URL
     * @return Response body as String
     * @throws Exception if request fails
     */
    private static String httpGet(String urlString) throws Exception {
        lastUrl = urlString;

        URL url = new URL(urlString);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();

        con.setRequestMethod("GET");
        lastStatus = con.getResponseCode();

        BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
        StringBuilder content = new StringBuilder();

        String line;
        while ((line = in.readLine()) != null) {
            content.append(line);
        }

        in.close();
        con.disconnect();

        return content.toString();
    }
}