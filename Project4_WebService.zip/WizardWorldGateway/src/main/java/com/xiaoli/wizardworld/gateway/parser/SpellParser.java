
/**
 * Author: Xiao Li (xiaol4)
 * Project 4 - WizardWorldGateway
 * Description: Utility parser for converting raw JSON spell list into JSONArray.
 * Reference: ChatGPT
 */
package com.xiaoli.wizardworld.gateway.parser;

import org.json.JSONArray;

public class SpellParser {

    /**
     * Parse a JSON string representing a list of spells into a JSONArray.
     * @param json raw JSON string returned from Wizard World API
     * @return JSONArray containing spell objects
     */
    public static JSONArray parseSpellList(String json) {
        return new JSONArray(json);
    }
}