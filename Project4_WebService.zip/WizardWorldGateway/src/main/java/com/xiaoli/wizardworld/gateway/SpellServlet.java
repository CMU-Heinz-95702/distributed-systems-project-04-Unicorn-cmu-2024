/**
 * Author: Xiao Li (xiaol4)
 * Project 4 - WizardWorldGateway
 * Description: Servlet that handles spell search requests from the Android client.
 * Reference: ChatGPT
 */
package com.xiaoli.wizardworld.gateway;

import com.xiaoli.wizardworld.gateway.client.WizardWorldAPIClient;
import com.xiaoli.wizardworld.gateway.dao.LogDAO;
import com.xiaoli.wizardworld.gateway.log.LogEntry;
import com.xiaoli.wizardworld.gateway.parser.SpellParser;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.Instant;

import org.json.JSONArray;

/** Servlet that receives parameters from mobile app, queries third‑party API, logs usage, and returns JSON results. */
public class SpellServlet extends HttpServlet {

    /**
     * Handle GET requests for spell lookup.
     * Steps:
     * 1. Read request parameters (name, type, incantation)
     * 2. Call WizardWorldAPIClient to fetch filtered spells
     * 3. Parse JSON into JSONArray
     * 4. Log request/response data into MongoDB
     * 5. Return JSON array to the Android client
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String name = req.getParameter("name");
        String type = req.getParameter("type");
        String incantation = req.getParameter("incantation");

        resp.setContentType("application/json");
        PrintWriter out = resp.getWriter();

        long start = System.currentTimeMillis();

        try {
            String json = WizardWorldAPIClient.fetchSpells(name, type, incantation);
            JSONArray spells = SpellParser.parseSpellList(json);

            // Calculate latency for the external API call
            long latency = System.currentTimeMillis() - start;

            // Restore logging
            LogEntry log = new LogEntry();
            log.setTimestamp(Instant.now().toString());
            log.setClientInput(name);
            log.setType(type);
            log.setIncantation(incantation);
            log.setLatencyMs(latency);
            log.setApiUrl(WizardWorldAPIClient.getLastUrl());
            log.setApiStatus(WizardWorldAPIClient.getLastStatus());
            log.setFound(spells.length() > 0);

            new LogDAO().insertLog(log);

            out.print(spells.toString());

        } catch (Exception e) {
            resp.setStatus(500);
            out.print("{\"error\": \"" + e.getMessage() + "\"}");
        }
    }
}