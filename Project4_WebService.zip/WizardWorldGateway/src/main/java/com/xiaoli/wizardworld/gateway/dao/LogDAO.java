/**
 * Author: Xiao Li (xiaol4)
 * Project 4 - WizardWorldGateway
 * Description: Data Access Object for inserting and querying logs in MongoDB.
 * Reference: ChatGPT
 */
package com.xiaoli.wizardworld.gateway.dao;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.xiaoli.wizardworld.gateway.log.LogEntry;
import org.bson.Document;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Sorts;

public class LogDAO {

    private static MongoCollection<Document> logs;

    /**
     * Static initializer: establishes MongoDB connection and initializes collection reference.
     */
    static {
        try {
            String uri =
                "mongodb+srv://xiaol4_db_user:1CvEvAdAPIeTqBRK@wizardworld.p6rgfx6.mongodb.net/?appName=WizardWorld";

            MongoClient client = MongoClients.create(uri);
            MongoDatabase db = client.getDatabase("WizardWorld");
            logs = db.getCollection("logs");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Insert a LogEntry into the MongoDB 'logs' collection.
     * @param entry LogEntry containing all logged fields
     */
    public void insertLog(LogEntry entry) {
        if (logs == null) return;

        Document doc = new Document()
                .append("timestamp", entry.getTimestamp())
                .append("clientInput", entry.getClientInput())
                .append("type", entry.getType())
                .append("incantation", entry.getIncantation())
                .append("latencyMs", entry.getLatencyMs())
                .append("apiUrl", entry.getApiUrl())
                .append("apiStatus", entry.getApiStatus())
                .append("found", entry.isFound());

        logs.insertOne(doc);
    }

    /**
     * Retrieve all logs sorted by timestamp (newest first).
     * @return List of Document objects
     */
    public List<Document> findAll() {
        List<Document> result = new ArrayList<>();
        logs.find().sort(Sorts.descending("timestamp")).into(result);
        return result;
    }

    /**
     * Compute the top N most frequently searched spell inputs.
     * @param N number of records to return
     * @return Aggregated list of Documents with fields: clientInput, count
     */
    public List<Document> getTopSearchedSpells(int N) {
        List<Document> result = new ArrayList<>();

        logs.aggregate(Arrays.asList(
                Aggregates.group("$clientInput", Accumulators.sum("count", 1)),
                Aggregates.sort(Sorts.descending("count")),
                Aggregates.limit(N)
        )).into(result);

        return result;
    }

    /**
     * Compute the average latency across all log entries.
     * @return average latency in milliseconds
     */
    public double getAverageLatency() {
        List<Document> result = new ArrayList<>();

        logs.aggregate(Arrays.asList(
                Aggregates.group(null, Accumulators.avg("avgLatency", "$latencyMs"))
        )).into(result);

        if (result.isEmpty()) return 0.0;
        return result.get(0).getDouble("avgLatency");
    }
}